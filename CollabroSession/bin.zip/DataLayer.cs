﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CollabroSession
{
    public class DataLayer
    {
        public DataClasses1DataContext da=new DataClasses1DataContext(@"workstation id=CollabroDb.mssql.somee.com;packet size=4096;user id=anch123_SQLLogin_1;pwd=prs2h6k7uu;data source=CollabroDb.mssql.somee.com;persist security info=False;initial catalog=CollabroDb");
    }
}